// GET /api/board … 先生画面用。みんなの意見をまとめて丸ごとに返す。
//
// まとめ方：
//  1) env.AI（Cloudflare Workers AI）があれば、意味の近さでまとめる（ai.js）
//  2) 使えない／失敗したときは、文字の並びの近さでまとめる（cluster.js）
// どちらでまとめたかは method（"ai" / "bigram"）で返す。

import { json, fail, getUser, isTeacher } from "../_lib/auth.js";
import { clusterize, medoidLabel } from "../_lib/cluster.js";
import { ensureVectors } from "../_lib/vectorstore.js";
import { clusterByVectors, medoidByVectors, DEFAULT_THRESHOLD } from "../_lib/ai.js";

export async function onRequestGet({ request, env }) {
  const user = await getUser(request, env);
  if (!user) return fail(401, "ログインしてね", "not_signed_in");
  if (!isTeacher(user, env)) {
    return fail(403, "この画面は先生だけが見られます", "not_teacher");
  }

  const { results } = await env.DB.prepare(
    "SELECT email, name, picture, opinion, reason, created_at FROM submissions ORDER BY created_at ASC"
  ).all();
  const items = results || [];

  let groups = [];
  let method = "none";
  let threshold = 0;
  let note = "";

  const byBigram = () =>
    clusterize(items).map((g) => ({ label: medoidLabel(g), members: g }));

  if (items.length > 0) {
    if (env.AI) {
      try {
        threshold = Number(env.SIMILARITY_THRESHOLD || DEFAULT_THRESHOLD);
        if (!(threshold > 0 && threshold <= 1)) threshold = DEFAULT_THRESHOLD;

        const vectors = await ensureVectors(env, items);
        groups = clusterByVectors(items, vectors, threshold).map((g) => ({
          label: medoidByVectors(g, vectors),
          members: g.map((x) => x.item),
        }));
        method = "ai";
      } catch (err) {
        note = String((err && err.message) || err);
        groups = byBigram();
        method = "bigram";
      }
    } else {
      note = "ai_binding_missing";
      groups = byBigram();
      method = "bigram";
    }
  }

  const clusters = groups
    .map((g, i) => ({
      id: "c" + i,
      label: g.label,
      count: g.members.length,
      members: g.members.map((m) => ({ name: m.name, picture: m.picture || "" })),
      reasons: g.members.map((m) => ({
        name: m.name,
        picture: m.picture || "",
        reason: m.reason,
        opinion: m.opinion,
      })),
    }))
    .sort((a, b) => b.count - a.count || String(a.label).localeCompare(String(b.label), "ja"));

  return json({
    ok: true,
    total: items.length,
    clusterCount: clusters.length,
    method,
    threshold,
    note,
    updatedAt: new Date().toISOString(),
    clusters,
  });
}
